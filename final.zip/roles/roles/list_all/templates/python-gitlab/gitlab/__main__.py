import gitlab.cli


__name__ == "__main__" and gitlab.cli.main()
